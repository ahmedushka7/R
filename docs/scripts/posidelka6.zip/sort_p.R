# СОРТИРОВКА ПУЗЫРЬКОМ
sort.p <- function(x){
  n <- length(x)
  for(i in (n-1):1){
    for(j in 1:i){
      if(x[j]>x[j+1]){
        a <- x[j]
        x[j] <- x[j+1]
        x[j+1] <- a
      }
    }
  }
  return(x)
}

x <- sample(1:100,20)
print(x)
print(sort.p(x))