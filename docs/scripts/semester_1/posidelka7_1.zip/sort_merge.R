# СОРТИРОВКА СЛИЯНИЕМ
MERGE <- function(A,B){ 
  C <- c() 
  while(length(A)>0 & length(B)>0){ 
    if(A[1]<B[1]){ 
      C <- c(C,A[1]) 
      A <- A[-1] 
    }else{ 
      C <- c(C,B[1]) 
      B <- B[-1] 
    } 
  } 
  C <- c(C,A,B) 
  return(C) 
} 

mergeSORT <- function(D){ 
  if(length(D)==1){ 
    return(D) 
  }else{ 
    mid <- length(D)%/%2 
    D <- MERGE(mergeSORT(D[1:mid]),mergeSORT(D[(mid+1):length(D)])) 
  } 
  return(D) 
}

D <- sample(1:100,30)
print(D)
print(mergeSORT(D))