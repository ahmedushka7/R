x <- c(2,7,5,4,1)
insertion.sort <- function(x){
  for(i in 2:length(x)){
    k <- i
    C <- x[i]
    for(j in (i-1):1){
      if(x[j] > C){
        x[j+1] <- x[j]
        k <- j
      }
    }
    x[k] <- C
  }
  return(x)
}

print(insertion.sort(x))