x <- c(23,3,50,7,25,2,24,0,23,100,102,99)
selection.sort <- function(x){
  for(i in length(x):2){
    M <- 1
    for(j in 2:i){
      if(x[j] > x[M]){
        M <- j
      }
    }
    P <- x[i]
    x[i] <- x[M]
    x[M] <- P
  }
  return(x)
}

print(selection.sort(x))
